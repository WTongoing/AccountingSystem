package application;

import java.util.Date;
import java.sql.*;

public class OrderInfo {
	
	   private int orderId;
	   private int userId;
	   private String type;
	   private double amount;
	   private String date;
	   private String description;
	   
	   public void setOrderId(int orderId) {
		   this.orderId=orderId;
	   }
	   
	   public int getOrderId() {
		   return orderId;
	   }
	   
	   public void setUserId(int userId) {
		   this.userId=userId;
	   }
	   
	   public int getUserId() {
		   return userId;
	   }
	   
	   public void setType(String type) {
		   this.type=type;
	   }
	   
	   public String getType() {
		   return type;
	   }
	   
	   public void setAmount(double amount) {
		   this.amount = amount;
	   }
	   
	   public double getAmount() {
		   String str_amount = String.format("%.2f",amount);
		   amount = Double.parseDouble(str_amount);
		   return amount;
	   }
	   
	   public void setDate(String date) {
		   this.date = date;
	   }
	   
	   public String getDate() {
		   return date;
	   }
	   
	   public void setDescription(String description) {
		   this.description = description;
	   }
	   
	   public String getDescription() {
		   return description;
	   }
}