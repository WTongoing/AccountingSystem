package application;
	
import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.stage.WindowEvent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;


public class Main extends Application {
	
	public Stage primaryStage = new Stage();
	public Scene Mainscene;
	public HBox MainPagePane = new HBox();
	//public AnchorPane MainPagePane = new AnchorPane();
	//private static AnchorPane ExpenditurePagePane = new AnchorPane();

	public static String consumptionType;
	
	@Override
	public void start(Stage primaryStage) throws IOException {
		this.primaryStage = primaryStage;
		ShowMainPageView();
	}
	
	public static void ShowMainPageView() throws IOException{

//		MainPagePane = FXMLLoader.load(Main.class.getResource("MainPage.fxml"));
		FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("MainPage.fxml"));
        HBox MainPagePane = (HBox) loader.load();
        MainPagePane.setStyle("-fx-background-color: gold;");
		
        Stage primaryStage = new Stage();
		Scene Mainscene = new Scene(MainPagePane,400,400);
		primaryStage.setTitle("Main Page");
		primaryStage.setScene(Mainscene);
		primaryStage.show();
	}
	
	public static void ShowExpenditurePageView() throws IOException{
		
		FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("ExpenditurePage.fxml"));
        AnchorPane ExpenditurePagePane = (AnchorPane) loader.load();
        ExpenditurePagePane.setStyle("-fx-background-color: gold;"); 
        //Khaki
        Stage stage = new Stage();
        Scene Expendscene = new Scene(ExpenditurePagePane);
        stage.setTitle("Expenditure Page");
        stage.setScene(Expendscene);
        stage.show();
	}
	
	public static void ShowAmountPageView() throws IOException{
		
		FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("AmountPage.fxml"));
        AnchorPane AmountPagePane = (AnchorPane) loader.load();
        AmountPagePane.setStyle("-fx-background-color: gold;"); 
        
        Stage stage = new Stage();
        Scene Amountscene = new Scene(AmountPagePane);
        stage.setTitle("Amount Page");
        stage.setScene(Amountscene);
        stage.show();
	}
	
	public static void ShowChartPageView() throws IOException{
		
		FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("ChartPage.fxml"));
        AnchorPane ChartPagePane = (AnchorPane) loader.load();
        
        Stage stage = new Stage();
        Scene Chartscene = new Scene(ChartPagePane);
        stage.setTitle("Chart Page");
        stage.setScene(Chartscene);
        stage.show();
	}
	
	public static void CloseMainPageView() throws IOException{
		
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
