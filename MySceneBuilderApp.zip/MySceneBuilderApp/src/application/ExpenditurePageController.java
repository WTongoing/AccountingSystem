package application;

import application.Main;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.io.IOException;

import javafx.application.Platform;
import javafx.event.ActionEvent;

public class ExpenditurePageController {
	public Main main;
	
//	@FXML
//	private Stage MainStage;
	
	@FXML
	private AnchorPane ExpenditurePagePane;
	
	@FXML
	private Button ButtonFood;
	
	@FXML
	private Button ButtonRent;
	
	@FXML
	private Button ButtonTraffic;
	
	@FXML
	private Button ButtonPharmacy;
	
	@FXML
	private Button ButtonEntertainment;
	
	@FXML
	private Button ButtonShopping;
	
	@FXML
	private Button ButtonNecessity;
	
	@FXML
	private Button ButtonOthers;
	
	@FXML
	private Button ButtonHome;
	
	@FXML
	public void ClickHome(ActionEvent event) throws IOException {
		System.out.println("Button Home has been Click!");
		CloseExpenditurePage();
		Main.ShowMainPageView();
	}

	public void CloseExpenditurePage() {
        Stage stage = (Stage)ButtonHome.getScene().getWindow();
        stage.close();
    }
	
	@FXML
	public void ClickButtonFood(ActionEvent event) throws IOException {
		System.out.println("Button Food has been Click!");
		Main.ShowAmountPageView();
		Main.consumptionType = "Food";
	}
	
	@FXML
	public void ClickButtonRent(ActionEvent event) throws IOException {
		System.out.println("Button Rent has been Click!");
		Main.ShowAmountPageView();
		Main.consumptionType = "Rent";
	}
	@FXML
	public void ClickButtonTraffic(ActionEvent event) throws IOException {
		System.out.println("Button Traffic has been Click!");
		Main.ShowAmountPageView();
		Main.consumptionType = "Traffic";
	}
	@FXML
	public void ClickButtonNecessity(ActionEvent event) throws IOException {
		System.out.println("Button Necessity has been Click!");
		Main.ShowAmountPageView();
		Main.consumptionType = "Necessity";
	}
	@FXML
	public void ClickButtonOthers(ActionEvent event) throws IOException {
		System.out.println("Button Others has been Click!");
		Main.ShowAmountPageView();
		Main.consumptionType = "Others";
	}
	@FXML
	public void ClickButtonPharmacy(ActionEvent event) throws IOException {
		System.out.println("Button Pharmacy has been Click!");
		Main.ShowAmountPageView();
		Main.consumptionType = "Pharmacy";
	}
	@FXML
	public void ClickButtonShopping(ActionEvent event) throws IOException {
		System.out.println("Button Shopping has been Click!");
		Main.ShowAmountPageView();
		Main.consumptionType = "Shopping";
	}
	@FXML
	public void ClickButtonEntertainment(ActionEvent event) throws IOException {
		System.out.println("Button Entertainment has been Click!");
		Main.ShowAmountPageView();
		Main.consumptionType = "Entertainment";
	}
}
