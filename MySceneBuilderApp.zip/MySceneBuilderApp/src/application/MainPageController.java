package application;

import application.Main;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.io.IOException;

import javafx.application.Platform;
import javafx.event.ActionEvent;

import java.sql.*;

public class MainPageController {
	
	public Main main;
	
//	@FXML
//	private Stage MainStage;
	
	@FXML
	private HBox MainPagePane;
	
	@FXML
	private Button ButtonAdd;
	
	@FXML
	private Button ButtonRecord;
	
	@FXML
	private Button ButtonChart;
	
	
	@FXML
	public void ClickAdd(ActionEvent event) throws IOException {
		System.out.println("Button Add has been Click!");
		CloseMainPage();
		Main.ShowExpenditurePageView();
	}
	
	@FXML
	public void CloseMainPage() {
        Stage stage = (Stage)ButtonAdd.getScene().getWindow();
        stage.close();
    }
	
	@FXML
	public void ClickChart(ActionEvent event) throws IOException {
		System.out.println("Button Chart has been Click!");
	    Main.ShowChartPageView();
	}
}
