package application;

import java.io.IOException;
import java.util.Random;

import dao.Dao;
import entity.Order_info;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;

public class ExpenditureAmountController {
	@FXML
	private AnchorPane AmountPagePane;
	
//	@FXML
//	private ComboBox<String> TypeBox = new ComboBox<String>();
	
	@FXML
 	private TextField Type;
	
	@FXML
	private DatePicker datepicker;
	
	@FXML
	private TextField AmountText;
	
	@FXML
	private TextArea NoteText;
	
	@FXML
	private Button AddRecord;
	
	@FXML
	private Alert alert;
	Dao<Order_info> orderDao = new Dao(new Order_info());

	@FXML
	public void initTypeValue() {
		Type.setPromptText("--"+Main.consumptionType+"--");
		Type.setEditable(false);
		Type.setFocusTraversable(false);
		Type.setDisable(true);
	}	
	
	Random r=new Random();
	
	@FXML
	public void AddRecordPrompt(ActionEvent actionevent) throws IOException{
		
		Order_info order=new Order_info();
		
		if(AmountText.getText().toString().trim().equals("")||datepicker.getValue()==null) {
			System.out.println("error");
			alert = new Alert(AlertType.ERROR);
			alert.setTitle("Error Dialog");
			alert.setHeaderText(null);
			alert.setContentText("Record cannot be import! consumption amount and date cannot be null!");
			alert.show();
		}else {
			order.setAmount(AmountText.getText());
			order.setDate(datepicker.getValue().toString());
			order.setDescription(NoteText.getText());
			order.setType(Main.consumptionType);
			order.setUserid("5802175");
			order.setOrderId(r.nextInt(1000000));
			orderDao.add(order);
			alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Confirmation Dialog");
			alert.setHeaderText(null);
			alert.setContentText("Record added successfully!");
			alert.show();
		}
	}
	
//	@FXML
//	public void initComboValue() {
//        String types[] = { "Food", "Rent", "Traffic", "Pharmacy"};
//		ObservableList<String> options = FXCollections.observableArrayList(types);
//		TypeBox.setItems(options);
//	}	
	
}
