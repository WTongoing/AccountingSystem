package entity;

public class Order_info implements java.io.Serializable {


	private Integer orderId;
	
	private String userid;
	public String getUserid() {
		return this.userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	private String type;
	public String getType() {
		return this.type;
	}
	public void setType(String type) {
		this.type = type;
	}
	private String amount;
	public String getAmount() {
		return this.amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	private String date;
	public String getDate() {
		return this.date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	private String description;
	public String getDescription() {
		return this.description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Integer getOrderId() {
		return orderId;
	}
	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}
	
}
